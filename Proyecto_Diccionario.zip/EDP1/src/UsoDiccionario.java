import java.util.Scanner;
import java.lang.*;

public class UsoDiccionario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String opcion = "";
        String clave = "";
        String valor = "";
        Diccionario diccionario = new Diccionario(10);

        System.out.println("--- Diccionario ---\n");

        while (!opcion.equals("salir")) {
            System.out.println("1. Insertar\n2. Buscar\n3. Eliminar\n4. Mostrar\nsalir\n");
            System.out.print("Escriba su opción: ");
            opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("Escriba la clave: ");
                    clave = sc.nextLine();
                    System.out.print("Escriba el valor: ");
                    valor = sc.nextLine();
                    diccionario.insertar(clave, valor);
                    System.out.println("Clave-valor insertados con éxito\n");
                    break;
                case "2":
                    System.out.print("Escriba la clave a buscar: ");
                    clave = sc.nextLine();
                    valor = diccionario.buscar(clave);
                    if (valor != null) {
                        System.out.println("Valor encontrado: " + valor + "\n");
                    } else {
                        System.out.println("La clave no se encuentra en el diccionario\n");
                    }
                    break;
                case "3":
                    System.out.print("Escriba la clave a eliminar: ");
                    clave = sc.nextLine();
                    valor = diccionario.eliminar(clave);
                    if (valor != null) {
                        System.out.println("Clave-valor eliminados con éxito\n");
                    } else {
                        System.out.println("La clave no se encuentra en el diccionario\n");
                    }
                    break;
                case "4":
                    diccionario.mostrar();
                    System.out.println();
                    break;
                case "salir":
                    System.out.println("Saliendo del programa...\n");
                    break;
                default:
                    System.out.println("Opción inválida, intente de nuevo\n");
            }
        }
        sc.close();
    }
}