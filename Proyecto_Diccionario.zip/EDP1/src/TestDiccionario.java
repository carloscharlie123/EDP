import org.junit.Test;

import static org.junit.Assert.*;

public class TestDiccionario {
	
    @Test
    public void testinsertarybuscar(){
    	Diccionario dict = new Diccionario();
    	dict.insertar("key1", "value1");
        dict.insertar("key2", "value2");
        dict.insertar("key3", "value3");
        assertEquals("value1", dict.buscar("key1"));
        assertEquals("value2", dict.buscar("key2"));
        assertEquals("value3", dict.buscar("key3"));
    }
    
    @Test
    public void testclaves(){
    	Diccionario dict = new Diccionario();
    	dict.insertar("key1", "value1");
        dict.insertar("key2", "value2");
        dict.insertar("key3", "value3");
        assertNotNull(dict.buscar("key1"));
        assertNotNull(dict.buscar("key2"));
        assertNotNull(dict.buscar("key3"));
        assertNotNull(dict.claves());
        boolean key1 = false;
        for(int i = 0; i < dict.claves().length;i++) {
    		if (dict.claves()[i] == "key1") key1 = true;
    	}
        assertTrue(key1);
        
        boolean key2 = false;
        for(int i = 0; i < dict.claves().length;i++) {
    		if (dict.claves()[i] == "key2") key2 = true;
    	}
        assertTrue(key2);
        boolean key3 = false;
        for(int i = 0; i < dict.claves().length;i++) {
    		if (dict.claves()[i] == "key3") key3 = true;
    	}
        assertTrue(key3);
    }
    
    @Test
    public void testvalores(){
    	Diccionario dict = new Diccionario();
    	dict.insertar("key1", "value1");
        dict.insertar("key2", "value2");
        dict.insertar("key3", "value3");
        assertNotNull(dict.buscar("key1"));
        assertNotNull(dict.buscar("key2"));
        assertNotNull(dict.buscar("key3"));
        assertNotNull(dict.claves());
        boolean value1 = false;
        for(int i = 0; i < dict.valores().length;i++) {
    		if (dict.valores()[i] == "value1") value1 = true;
    	}
        assertTrue(value1);
        
        boolean value2 = false;
        for(int i = 0; i < dict.valores().length;i++) {
    		if (dict.valores()[i] == "value2") value2 = true;
    	}
        assertTrue(value2);
        boolean value3 = false;
        for(int i = 0; i < dict.valores().length;i++) {
    		if (dict.valores()[i] == "value3") value3 = true;
    	}
        assertTrue(value3);
    }
    
    @Test
    public void testvaloresyclaves() {
    	Diccionario dict = new Diccionario();
    	dict.insertar("key1", "value1");
        dict.insertar("key2", "value2");
        dict.insertar("key3", "value3");
        assertNotNull(dict.valoresyclaves());
        boolean key1 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][0] == "key1") key1 = true;
    	}
        assertTrue(key1);
        boolean key2 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][0] == "key2") key2 = true;
    	}
        assertTrue(key2);
        boolean key3 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][0] == "key3") key3 = true;
    	}
        assertTrue(key3);
        boolean value1 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][1] == "value1") value1 = true;
    	}
        assertTrue(value1);
        boolean value2 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][1] == "value2") value2 = true;
    	}
        assertTrue(value2);
        boolean value3 = false;
        for(int i = 0; i < dict.valoresyclaves().length;i++) {
    		if (dict.valoresyclaves()[i][1] == "value3") value3 = true;
    	}
        assertTrue(value3);
    }
        
    @Test
    public void testeliminar() {
        Diccionario dict = new Diccionario();
        dict.insertar("key1", "value1");
        dict.insertar("key2", "value2");
        dict.insertar("key3", "value3");
        dict.eliminar("key2");
        assertEquals("value1", dict.buscar("key1"));
        assertNull(dict.buscar("key2"));
    }
}